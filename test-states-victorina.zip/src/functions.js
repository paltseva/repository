function getName(text) {
    var n = text.split(" ");
    return n[n.length - 1];
}